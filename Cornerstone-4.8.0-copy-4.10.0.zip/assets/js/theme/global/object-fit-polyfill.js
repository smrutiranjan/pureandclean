import objectFitImages from 'object-fit-images';

export default function () {
    objectFitImages();
}
